import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Home(),
  ));
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Offset _startLastOffset = Offset.zero;
  Offset _lastOffset = Offset.zero;
  Offset _currentOffset = Offset.zero;
  double _lastScale = 1.0;
  double _currentScale = 1.0;
  var _onScaleStart;
  var _onScaleUpdate;
  var _onLongPress;
  var _onDoubleTap;
  @override
  void initState() {
    super.initState();

    _onScaleStart = (details) {
      _startLastOffset = details.focalPoint;
      _lastOffset = _currentOffset;
      _lastScale = _currentScale;
    };

    _onScaleUpdate = (details) {
      double newScale = _lastScale * details.scale;
      if (newScale < 1.0) {
        newScale = 1.0;
      }
      Offset delta = details.focalPoint - _startLastOffset;
      Offset newOffset = _lastOffset + delta / _lastScale;

      setState(() {
        _currentScale = newScale;
        _currentOffset = newOffset;
      });
    };

    _onLongPress = () {
      // Handle long press gesture if needed
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Long Press Detected"),
            content: Text("You long-pressed the image."),
            actions: [
              TextButton(
                child: Text("Close"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    };

    _onDoubleTap = () {
      // Handle double tap gesture if needed
      setState(() {
        _currentScale = 1.0;
        _currentOffset = Offset.zero;
      });
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    return GestureDetector(
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          _transformScaleAndTranslate(),
          _positionedStatusBar(context),
        ],
      ),
      onScaleStart: _onScaleStart,
      onScaleUpdate: _onScaleUpdate,
      onDoubleTap: _onDoubleTap,
      onLongPress: _onLongPress,
    );
  }

  Transform _transformScaleAndTranslate() {
    return Transform.scale(
      scale: _currentScale,
      child: Transform.translate(
        offset: _currentOffset,
        child: Image(
          image: AssetImage('assets/images/elephant.jfif'),
        ),
      ),
    );
  }

  Positioned _positionedStatusBar(BuildContext context) {
    return Positioned(
      top: 0.0,
      width: MediaQuery.of(context).size.width,
      child: Container(
        color: Colors.white54,
        height: 50.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Text(
              'Scale: ${_currentScale.toStringAsFixed(4)}',
            ),
            Text(
              'Current: $_currentOffset',
            ),
          ],
        ),
      ),
    );
  }
}
